﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LibraryManagement.Models;
namespace LibraryManagement.Controllers
{
    public class LibrarianrolesController : Controller
    {
        private LibraryEntities1 db = new LibraryEntities1();

        // GET: Librarianroles
        public ActionResult Index()
        {
            return View();
        }


       
    }
}