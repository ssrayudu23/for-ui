﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LibraryManagement.Controllers
{
    public class EmployeerolesController : Controller
    {
        // GET: Employeeroles
        public ActionResult Index()
        {
           

            return View();
        }
    }
}