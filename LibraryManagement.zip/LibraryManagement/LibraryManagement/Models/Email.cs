﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace LibraryManagement.Models
{
    public class Email
    {
        [Required,Display(Name ="your name")]
        public string FromName { get; set; }
        [Required, Display(Name = "your email"),EmailAddress]
        
        public string FromMail { get; set; }
        [Required]
        public string Message { get; set; }
        [Required, Display(Name = "To email"), EmailAddress]
        public string ToMail { get; set; }
    }
}