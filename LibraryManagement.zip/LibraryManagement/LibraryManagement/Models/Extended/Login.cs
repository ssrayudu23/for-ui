﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace LibraryManagement.Models.Extended
{
    public class Login
    {

        [Required(ErrorMessage = "Username is mandatory")]
        public string Username { get; set; }
        //[Required(ErrorMessage = "Name is mandatory")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Password is mandatory")]
        public string Password { get; set; }
        //[Required(ErrorMessage = "EmailAddress is mandatory")]
        public string EmailId { get; set; }

    }
}