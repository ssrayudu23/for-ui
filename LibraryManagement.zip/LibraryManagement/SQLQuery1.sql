Select*from Issuebook

select*from Book
select*from Users
Select*from Issuebook




ALTER TABLE IssueBook
ADD Status Varchar(52);

ALTER TABLE IssueBook
ADD EmailId Varchar(52);



	Select*from IssueBook
ALTER TABLE IssueBook
ADD CONSTRAINT CHK_Status CHECK (Status='Request' or Status='Approved' or Status='Cancelled');




